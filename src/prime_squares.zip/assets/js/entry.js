var Vue = require('./lib/vue.js');
var game = require('./game.js');